package com.cg.jpa.service;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public Employee save(Empployee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> loadAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
