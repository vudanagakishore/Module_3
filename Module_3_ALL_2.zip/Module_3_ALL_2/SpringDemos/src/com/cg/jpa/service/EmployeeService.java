package com.cg.jpa.service;

public interface EmployeeService 
{
	public abstract Employee save(Empployee employee);
	
	public abstract List<Employee> loadAll();
}
