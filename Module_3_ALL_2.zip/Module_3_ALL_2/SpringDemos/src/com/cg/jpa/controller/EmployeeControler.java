package com.cg.jpa.controller;

public class EmployeeControler 
{
	
}
