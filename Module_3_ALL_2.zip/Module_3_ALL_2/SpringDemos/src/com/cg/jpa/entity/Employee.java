package com.cg.jpa.entity;

public class Employee {

}
