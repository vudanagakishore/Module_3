package com.cg.editor;

public class SqlDateEditor extends PropertyEditorSupport{

}
