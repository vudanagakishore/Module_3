package com.cg.editor;

public class EmployeeClient 
{
	public static void main(String[] args) 
	{
		//ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
	}
}
