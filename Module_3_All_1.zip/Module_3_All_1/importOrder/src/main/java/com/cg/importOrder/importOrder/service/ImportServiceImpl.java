package com.cg.importOrder.importOrder.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.importOrder.importOrder.OrderException.OrderException;
import com.cg.importOrder.importOrder.bean.Import;
import com.cg.importOrder.importOrder.dao.ImportDao;


@Service
public class ImportServiceImpl implements ImportService {
	
	@Autowired
	ImportDao imports;   //object for dao class

	@Override
	public List<Import> getAllOrders() throws OrderException {

		try
		{
			return imports.findAll();
		}
		catch(Exception e) 
		{
			throw new OrderException(e.getMessage());
		}
	}

	@Override
	public List<Import> addOrder(Import p) throws OrderException {

		try
		{
			double amount = p.getPrice()*75*p.getQuantity();
			double charges = amount*0.0125;
			p.setAmount(amount);
			p.setCharges(charges);
			imports.save(p); 
			return imports.findAll();
		}
		catch(Exception e)
		{
		throw new OrderException(e.getMessage());
		}
	}

	@Override
	public List<Import> updateOrder(int id, Import pro) throws OrderException {
		try 
		{
			Optional<Import> optional=imports.findById(id);
			if(optional.isPresent()) 
			{
				Import product=optional.get();
				product.setPrice(pro.getPrice());
				product.setQuantity(pro.getQuantity());
				double amount=pro.getPrice()*75*pro.getQuantity();
				double charges = amount* 0.0125;
				product.setAmount(amount);
				product.setCharges(charges);
				imports.save(product);			
			}
			return getAllOrders();
		}
		catch(Exception e)
		{
			throw new OrderException(e.getMessage());
		}
	}

	@Override
	public List<Import> findByQuantity(int quantity, int quantity1) throws OrderException {
		try
		{
			return imports.findByQuantity(quantity,quantity1);
		}
		catch(Exception e) 
		{
			throw new OrderException(e.getMessage());
		}
	}

	@Override
	public List<Import> findByAmount(double amount) throws OrderException {
		try
		{
			return imports.findByAmount(amount);
		}
		catch(Exception e) 
		{
			throw new OrderException(e.getMessage());
		}
	}

}
